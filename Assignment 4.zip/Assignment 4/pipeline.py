"""
pipeline.py - Orchestrator for multi-crew pipeline with retry logic and checkpointing
"""

import json
import time
import os
import sys
from datetime import datetime
from typing import List, Any, Dict
from dotenv import load_dotenv

from crews import CREWS, CREW_NAMES, research_crew, analysis_crew, summary_crew

# Load environment variables
load_dotenv()


class PipelineOrchestrator:
    """
    Orchestrator that manages sequential execution of multiple crews
    with retry logic and checkpointing for fault tolerance.
    """
    
    def __init__(self, checkpoint_path: str = "checkpoint.json"):
        self.checkpoint_path = checkpoint_path
        self.crews = CREWS
        self.crew_names = CREW_NAMES
        self.max_retries = 3
        self.retry_delay_base = 2  # seconds, will be 2, 4, 8 seconds
        
    def load_checkpoint(self) -> Dict[str, Any]:
        """Load saved checkpoint data from JSON file."""
        if os.path.exists(self.checkpoint_path):
            try:
                with open(self.checkpoint_path, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                print(f"Warning: Could not parse {self.checkpoint_path}, starting fresh")
                return {}
        return {}
    
    def save_checkpoint(self, state: Dict[str, Any]) -> None:
        """Save current state to checkpoint file."""
        with open(self.checkpoint_path, 'w') as f:
            json.dump(state, f, indent=2)
        print(f"   [Checkpoint saved to {self.checkpoint_path}]")
    
    def log_stage_start(self, stage_name: str, stage_index: int) -> None:
        """Log the start of a pipeline stage."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"\n{'='*60}")
        print(f"[{timestamp}] 🚀 STAGE {stage_index + 1}: {stage_name} - STARTED")
        print(f"{'='*60}")
    
    def log_stage_complete(self, stage_name: str, result_preview: str = "") -> None:
        """Log successful completion of a pipeline stage."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"\n[{timestamp}] ✅ STAGE: {stage_name} - COMPLETED")
        if result_preview:
            preview = result_preview[:200] + "..." if len(result_preview) > 200 else result_preview
            print(f"   Output preview: {preview}")
    
    def log_stage_failed(self, stage_name: str, error: Exception) -> None:
        """Log failure of a pipeline stage."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"\n[{timestamp}] ❌ STAGE: {stage_name} - FAILED")
        print(f"   Error: {str(error)}")
    
    def log_retry(self, stage_name: str, attempt: int, error: Exception) -> None:
        """Log a retry attempt."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"\n[{timestamp}] 🔄 STAGE: {stage_name} - RETRY {attempt + 1}/{self.max_retries}")
        print(f"   Error: {str(error)}")
        print(f"   Waiting {self.retry_delay_base ** attempt} seconds...")
    
    def log_skip_stage(self, stage_name: str) -> None:
        """Log that a stage is being skipped due to checkpoint."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"\n[{timestamp}] ⏭️  STAGE: {stage_name} - SKIPPED (already completed)")
    
    def execute_crew_with_retry(self, crew, stage_name: str, inputs: Dict[str, Any]) -> str:
        """
        Execute a crew with retry logic for transient failures.
        
        Args:
            crew: The CrewAI crew to execute
            stage_name: Name of the stage for logging
            inputs: Input dictionary to pass to crew.kickoff()
            
        Returns:
            String result from the crew execution
            
        Raises:
            RuntimeError: After all retry attempts fail
        """
        last_error = None
        
        for attempt in range(self.max_retries):
            try:
                print(f"   Attempt {attempt + 1}/{self.max_retries}...")
                result = crew.kickoff(inputs=inputs)
                
                # Convert result to string if needed
                result_str = str(result)
                
                print(f"   ✓ Success on attempt {attempt + 1}")
                return result_str
                
            except Exception as e:
                last_error = e
                self.log_retry(stage_name, attempt, e)
                
                if attempt < self.max_retries - 1:
                    # Exponential backoff: 2^attempt seconds
                    delay = self.retry_delay_base ** attempt
                    time.sleep(delay)
                else:
                    self.log_stage_failed(stage_name, e)
        
        raise RuntimeError(f"Stage '{stage_name}' failed after {self.max_retries} attempts. Last error: {last_error}")
    
    def run(self, initial_input: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Run the complete pipeline with checkpoint resume capability.
        
        Args:
            initial_input: Dictionary with initial input for the first crew.
                          Should contain at least 'topic' key.
                          
        Returns:
            Dictionary with final state containing all stage results
        """
        print("\n" + "="*70)
        print("🚀 PIPELINE ORCHESTRATOR STARTING")
        print("="*70)
        print(f"📁 Checkpoint file: {self.checkpoint_path}")
        print(f"🔄 Max retries per stage: {self.max_retries}")
        print(f"⏱️  Retry delay base: {self.retry_delay_base} seconds (exponential backoff)")
        
        # Load existing checkpoint
        state = self.load_checkpoint()
        print(f"\n📋 Loaded checkpoint with {len(state)} completed stages: {list(state.keys())}")
        
        # Prepare input for first stage
        current_input = initial_input or {}
        if 'topic' not in current_input:
            current_input['topic'] = "The impact of artificial intelligence on healthcare"
            print(f"\n💡 No topic provided, using default: '{current_input['topic']}'")
        
        # Execute each stage sequentially
        for i, (crew, stage_name) in enumerate(zip(self.crews, self.crew_names)):
            stage_key = f"stage_{i}_{stage_name.lower()}"
            
            # Check if this stage is already completed
            if stage_key in state:
                self.log_skip_stage(stage_name)
                # Pass previous result as input for next stage
                current_input = {"previous_result": state[stage_key]}
                continue
            
            # Execute the stage
            self.log_stage_start(stage_name, i)
            
            try:
                # Execute crew with retry logic
                result = self.execute_crew_with_retry(crew, stage_name, current_input)
                
                # Save to state and checkpoint
                state[stage_key] = result
                self.save_checkpoint(state)
                
                # Log completion
                self.log_stage_complete(stage_name, result)
                
                # Prepare input for next stage
                current_input = {"previous_result": result}
                
            except Exception as e:
                print(f"\n{'='*60}")
                print(f"💥 PIPELINE FAILED at stage: {stage_name}")
                print(f"   Error: {e}")
                print(f"   Checkpoint saved. Run again to resume from this stage.")
                print(f"{'='*60}")
                raise
        
        # Pipeline complete
        print("\n" + "="*70)
        print("🎉 PIPELINE COMPLETED SUCCESSFULLY!")
        print("="*70)
        print(f"✅ All {len(self.crews)} stages completed")
        print(f"📁 Final checkpoint saved to {self.checkpoint_path}")
        
        return state
    
    def reset_checkpoint(self) -> None:
        """Delete the checkpoint file to start fresh."""
        if os.path.exists(self.checkpoint_path):
            os.remove(self.checkpoint_path)
            print(f"🗑️  Checkpoint file {self.checkpoint_path} deleted.")
        else:
            print(f"No checkpoint file found at {self.checkpoint_path}")


def run_pipeline(topic: str = None, resume: bool = True, reset: bool = False):
    """
    Convenience function to run the pipeline.
    
    Args:
        topic: Research topic (default: AI in healthcare)
        resume: Whether to resume from checkpoint (default: True)
        reset: Whether to reset checkpoint before running (default: False)
    """
    orchestrator = PipelineOrchestrator()
    
    if reset:
        orchestrator.reset_checkpoint()
        resume = False
    
    if not resume:
        # Delete checkpoint to force fresh run
        orchestrator.reset_checkpoint()
    
    initial_input = {"topic": topic} if topic else None
    
    try:
        results = orchestrator.run(initial_input=initial_input)
        
        # Print final summary
        print("\n" + "="*70)
        print("📊 FINAL RESULTS SUMMARY")
        print("="*70)
        for stage, result in results.items():
            print(f"\n--- {stage.upper()} ---")
            print(f"Length: {len(result)} characters")
            print(f"Preview: {result[:150]}..." if len(result) > 150 else result)
        
        return results
        
    except Exception as e:
        print(f"\n❌ Pipeline failed: {e}")
        print("Run the script again to resume from the last successful stage.")
        return None


def demo_resume_capability():
    """
    Demonstrate the resume capability by showing how it works.
    This doesn't actually run anything, just explains.
    """
    print("\n" + "="*70)
    print("🔄 RESUME CAPABILITY DEMO")
    print("="*70)
    print("""
    The checkpoint system allows the pipeline to resume after failure:
    
    1. After each successful stage, results are saved to checkpoint.json
    
    2. If the pipeline fails at stage 2 (Analysis), checkpoint.json contains:
       - stage_0_research: "completed research result"
       
    3. When you run the pipeline again:
       - Stage 0 (Research) is SKIPPED (already in checkpoint)
       - Stage 1 (Analysis) starts fresh with the saved research result
       
    4. To test this:
       - Run normally: python pipeline.py --topic "your topic"
       - Force failure: (modify code to raise exception)
       - Run again: python pipeline.py --topic "your topic"
       - Observe the skipped stage!
    
    5. To force a fresh run:
       python pipeline.py --reset
    """)


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Run the CrewAI orchestration pipeline")
    parser.add_argument("--topic", type=str, help="Research topic", 
                       default="The impact of artificial intelligence on healthcare")
    parser.add_argument("--reset", action="store_true", 
                       help="Reset checkpoint and run fresh")
    parser.add_argument("--demo-resume", action="store_true",
                       help="Show demo of resume capability")
    
    args = parser.parse_args()
    
    if args.demo_resume:
        demo_resume_capability()
    else:
        run_pipeline(topic=args.topic, resume=True, reset=args.reset)