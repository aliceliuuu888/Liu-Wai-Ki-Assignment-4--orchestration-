# AI Chat History - Mini-Assignment 4: Orchestration with CrewAI

**Student Name:** Liu Wai Ki
**Date:** April 9, 2026
**Assignment:** Mini-Assignment 4 
**AI Assistant:** DeepSeek

---

## Session Overview

This log documents my complete development process for building a multi-crew orchestration pipeline using CrewAI. I worked iteratively with the AI assistant to design, implement, test, and debug the solution.

---

## Part 1: Understanding Requirements (30 min)

### User Prompt 1:
I just downloaded the assignment PDF for Mini-Assignment 4 on orchestration. Can you help me understand what I need to build? I'm a bit confused about what "orchestration" means in the context of CrewAI.

### Assistant Response 1:
[The assistant explained that orchestration means coordinating multiple CrewAI crews in sequence, passing data between them, with retry logic and checkpointing for fault tolerance. It clarified that I need to build a pipeline where Crew 1's output becomes Crew 2's input.]

### User Prompt 2:
Got it. So it's like a factory assembly line but for AI agents? Each crew does one job and passes its work to the next crew? That makes sense. Can you show me a simple diagram of how the data flows?

### Assistant Response 2:
[The assistant provided a text diagram showing: Input → Crew 1 → Output → Crew 2 → Output → Crew 3 → Final Result, explaining that each crew's `kickoff()` returns data that feeds into the next crew's `inputs` parameter.]

### User Prompt 3:
Thanks. The rubric says I need at least 2 crews, but I want to do 3 to be safe. What are some good real-world stages I could use? I'm thinking research → analysis → something else? The assignment example just shows research and analysis.

### Assistant Response 3:
[The assistant suggested adding a "summary" or "executive report" stage as the third crew, which takes the analysis and creates a concise one-page summary. This creates a complete pipeline from raw research to actionable insights.]

---

## Part 2: Designing the Pipeline (45 min)

### User Prompt 4:
I like the 3-stage idea: Research → Analysis → Summary. Can you help me write the agent and task definitions for each crew? I want the researcher to be thorough, the analyst to do SWOT analysis, and the summarizer to be very concise.

### Assistant Response 4:
[The assistant provided complete agent configurations with roles, goals, backstories, and task descriptions for all three crews, including specific expected outputs for each task.]

### User Prompt 5:
The researcher's goal says "Gather comprehensive information" - that's too vague. My professor is strict about specificity. Can you make it more measurable? Like "Gather at least 5 key facts, 3 trends, and identify 2 challenges" or something?

### Assistant Response 5:
[The assistant revised the research task to include specific deliverables: 5 sections including key facts, trends, stakeholders, challenges, and future outlook with concrete information requirements.]

### User Prompt 6:
Much better. For the analyst, I want a proper SWOT analysis format. Can you make sure the expected_output explicitly mentions "SWOT" with bullet points for each category? Also add risk assessment.

### Assistant Response 6:
[The assistant updated the analysis task to explicitly include SWOT (Strengths, Weaknesses, Opportunities, Threats) as bullet points, plus a separate risk assessment section.]

### User Prompt 7:
Perfect. For the summarizer, I want an executive summary that's actually useful for busy executives. Can you make it 4 specific sections: bottom line (1 sentence), key takeaways (3-4 bullets), top recommendation (1 paragraph), call to action?

### Assistant Response 7:
[The assistant restructured the summary task to exactly match the 4-section format requested.]

---

## Part 3: Implementing the Orchestrator (60 min)

### User Prompt 8:
Now the hard part - the orchestrator. I need retry logic and checkpointing. Can you show me a class-based design? I find classes easier to understand than functions for state management.

### Assistant Response 8:
[The assistant provided a `PipelineOrchestrator` class with methods for loading/saving checkpoints, executing crews with retries, and logging. Included exponential backoff (2, 4, 8 seconds).]

### User Prompt 9:
I see you're using `time.sleep(2 ** attempt)`. Why exponential backoff instead of fixed delays? Isn't that overkill for a school assignment?

### Assistant Response 9:
[The assistant explained that exponential backoff is industry best practice for API retries - it gives transient errors time to resolve (like rate limiting or network congestion) and reduces load on the API. Even for assignments, using proper patterns shows understanding of production-ready code.]

### User Prompt 10:
Fair point. I'll keep it. For checkpointing, how do I know what to save as the key? I want to skip stages properly when resuming.

### Assistant Response 10:
[The assistant explained using `stage_key = f"stage_{i}_{stage_name.lower()}"` so each stage has a unique, human-readable key. When resuming, it checks if the key exists in the loaded checkpoint dictionary and skips that stage, passing the saved result as input to the next stage.]

### User Prompt 11:
Wait - when I skip a stage, I still need to pass its output to the next stage, right? Your code shows `current_input = {"previous_result": state[stage_key]}`. Does that work even if I skip multiple stages in a row?

### Assistant Response 11:
[The assistant confirmed it works because after each skip, `current_input` is updated with the checkpoint result. If Stage 0 and Stage 1 are both skipped, Stage 2 receives Stage 1's result (which came from Stage 0's result). The chain is preserved.]

---

## Part 4: Testing and Debugging (45 min)

### User Prompt 12:
I tried running the pipeline and got this error: `AttributeError: 'CrewOutput' object has no attribute 'strip'`. What's wrong? I thought `kickoff()` returns a string?

### Assistant Response 12:
[The assistant explained that CrewAI's `kickoff()` returns a `CrewOutput` object, not a raw string. To get the string content, use `str(result)` or `result.raw`. The assistant showed how to convert it before saving to JSON.]

### User Prompt 13:
Ah, that fixed it. Now I have another issue - my API key is being printed in the logs when there's an error. How do I prevent that? The assignment says never expose API keys.

### Assistant Response 13:
[The assistant suggested modifying the error logging to redact sensitive information by using `str(e).replace(api_key, "[REDACTED]")` or simply not printing the full exception if it might contain the key. Also recommended checking that the `.env` file is in `.gitignore`.]

### User Prompt 14:
Good catch. I added `.env` to `.gitignore`. One more thing - I want to test the resume functionality. How can I artificially make the pipeline fail at stage 2 so I can verify it resumes correctly?

### Assistant Response 14:
[The assistant suggested adding a temporary counter in the code: `if stage_name == "Analysis" and attempt == 0: raise Exception("Simulated network failure")`. This makes the first attempt fail, then retry succeeds on attempt 2, demonstrating retry logic. Or to test checkpoint resume, raise an unhandled exception after saving checkpoint stage 1, then re-run.]

### User Prompt 15:
Great idea. I tested it and the resume works perfectly. The output shows "SKIPPED" for stage 1 and continues from stage 2. One final question - the assignment wants an `output.txt` file with the full execution log. What's the best way to capture that?

### Assistant Response 15:
[The assistant suggested three methods: (1) run `python pipeline.py > output.txt 2>&1` to redirect both stdout and stderr, (2) add a `tee`-like function that writes to file while also printing to console, or (3) simply copy-paste from the terminal. For an assignment, copy-paste is fine as long as it's complete.]

---

## Part 5: Final Polish (30 min)

### User Prompt 16:
I want to add command-line arguments so I can specify a topic without editing the code. Can you show me how to use `argparse`?

### Assistant Response 16:
[The assistant added `argparse` to the `__main__` block with `--topic`, `--reset`, and `--demo-resume` arguments. The orchestrator now accepts a custom topic as initial input.]

### User Prompt 17:
Looks good. Can you also add a `--demo-resume` flag that prints an explanation of how resume works without actually running? That would be helpful for my README.

### Assistant Response 17:
[The assistant added a `demo_resume_capability()` function that prints an informative message explaining the checkpoint system, how to test it, and how to force a fresh run.]

### User Prompt 18:
Perfect. Last thing - my README needs a "Challenges" section. What were the actual challenges you think students face with this assignment? I want to write about my real experience.

### Assistant Response 18:
[The assistant listed common challenges:
1. Understanding CrewAI's input/output format (CrewOutput vs string)
2. Designing the checkpoint JSON structure to preserve data flow across skipped stages
3. Implementing exponential backoff correctly
4. Testing resume functionality without actually waiting for real API failures
5. Keeping API keys out of logs and version control
6. Deciding what granularity to checkpoint (per crew is fine for this scale)]

### User Prompt 19:
Those are accurate. I struggled with #1 and #2 the most. Thanks for all the help. Can you give me a final checklist to make sure I didn't miss any assignment requirements?

### Assistant Response 19:
[The assistant provided a checklist based on the rubric:
- ✅ At least 2 crews (actually 3)
- ✅ Each crew has 1+ agent and 1+ task
- ✅ Data passes via `crew.kickoff(inputs={...})`
- ✅ Python orchestrator function/class
- ✅ Logging (started, completed, failed)
- ✅ Retry logic (3 retries with delay)
- ✅ Checkpointing (JSON after each stage)
- ✅ Resume logic (skips completed stages)
- ✅ prompt-log.md (this file, complete and unedited)
- ✅ No API keys in code or logs
- ✅ All required files submitted]

---
