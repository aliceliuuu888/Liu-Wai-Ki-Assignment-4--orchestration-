"""
crews.py - CrewAI agent and crew definitions for the research and analysis pipeline
"""

import os
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM

# Load environment variables
load_dotenv()

# Initialize LLM
llm = LLM(
    model=os.getenv("DEEPSEEK_MODEL", "deepseek-chat"),
    base_url=os.getenv("DEEPSEEK_API_BASE", "https://api.deepseek.com"),
    api_key=os.getenv("DEEPSEEK_API_KEY"),
)

# ============================================================
# CREW 1: Research Crew - Gather information on a topic
# ============================================================

researcher = Agent(
    role="Senior Research Analyst",
    goal="Gather comprehensive and accurate information about the given topic",
    backstory="""You are an experienced research analyst with expertise in 
    gathering, verifying, and synthesizing information from various sources. 
    You are known for your thoroughness and attention to detail. You always 
    provide factual, well-organized research outputs.""",
    llm=llm,
    verbose=True,
    allow_delegation=False,
)

research_task = Task(
    description="""
    Research the following topic thoroughly: {topic}
    
    Provide a comprehensive research report that includes:
    1. Key facts and figures about the topic
    2. Main trends or developments
    3. Important stakeholders or key players
    4. Any controversies or challenges
    5. Future outlook
    
    Be specific and provide concrete information. Your research should be 
    detailed enough that someone unfamiliar with the topic can understand it.
    """,
    expected_output="A detailed research report with 5 sections as outlined above, approximately 300-500 words",
    agent=researcher,
)

research_crew = Crew(
    agents=[researcher],
    tasks=[research_task],
    process=Process.sequential,
    verbose=True,
)

# ============================================================
# CREW 2: Analysis Crew - Analyze the research and provide insights
# ============================================================

analyst = Agent(
    role="Strategic Analyst",
    goal="Analyze research data and provide actionable insights and recommendations",
    backstory="""You are a strategic analyst who excels at finding patterns, 
    drawing conclusions, and making recommendations based on data. You have 
    a knack for identifying what's truly important and what can be ignored. 
    Your insights are practical and actionable.""",
    llm=llm,
    verbose=True,
    allow_delegation=False,
)

analysis_task = Task(
    description="""
    Analyze the following research report and provide strategic insights:
    
    RESEARCH REPORT:
    {previous_result}
    
    Your analysis should include:
    1. Executive summary of key findings (2-3 bullet points)
    2. SWOT analysis (Strengths, Weaknesses, Opportunities, Threats)
    3. Top 3 strategic recommendations based on the research
    4. Potential risks to consider
    5. Conclusion with next steps
    
    Make your analysis practical and actionable. Focus on what matters most.
    """,
    expected_output="A strategic analysis report with 5 sections including SWOT, 3 recommendations, and risk assessment",
    agent=analyst,
)

analysis_crew = Crew(
    agents=[analyst],
    tasks=[analysis_task],
    process=Process.sequential,
    verbose=True,
)

# ============================================================
# OPTIONAL CREW 3: Summary Crew - Create an executive summary
# ============================================================

summarizer = Agent(
    role="Executive Summarizer",
    goal="Create concise, impactful executive summaries from detailed analysis",
    backstory="""You are an expert communicator who takes complex information 
    and distills it into clear, concise summaries. Executives love your work 
    because you get straight to the point without losing important details.""",
    llm=llm,
    verbose=True,
    allow_delegation=False,
)

summary_task = Task(
    description="""
    Create an executive summary from this strategic analysis:
    
    STRATEGIC ANALYSIS:
    {previous_result}
    
    Create a ONE-PAGE executive summary that includes:
    1. The bottom line (1 sentence)
    2. Key takeaways (3-4 bullet points)
    3. Top recommendation (1 paragraph)
    4. Call to action
    
    Keep it extremely concise and impactful. No fluff.
    """,
    expected_output="A one-page executive summary (approximately 150-250 words) with the 4 sections above",
    agent=summarizer,
)

summary_crew = Crew(
    agents=[summarizer],
    tasks=[summary_task],
    process=Process.sequential,
    verbose=True,
)

# Crew list for the pipeline
CREWS = [research_crew, analysis_crew, summary_crew]
CREW_NAMES = ["Research", "Analysis", "Summary"]